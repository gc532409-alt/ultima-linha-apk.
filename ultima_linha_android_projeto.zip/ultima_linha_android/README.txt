ULTIMA LINHA 3.1 — PROJETO ANDROID

Este projeto empacota o jogo HTML local em um app Android usando WebView.
Requisitos para compilar:
- Android Studio
- JDK 17
- Android SDK 35

Como gerar o APK:
1. Abra a pasta 'ultima_linha_android' no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Se necessário, instale Android SDK Platform 35 pelo SDK Manager.
4. Vá em Build > Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de teste aparecerá em app/build/outputs/apk/debug/app-debug.apk.

O jogo fica dentro de app/src/main/assets/index.html e funciona offline.
